'use client';

import { useState, useMemo, useEffect } from 'react';
import { useFinanceStore } from '@/lib/store/useFinanceStore';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Plus, Trash2, Edit, TrendingDown, TrendingUp, Loader2 } from 'lucide-react';
import { FinanceDialog } from '@/components/finance/finance-dialog';
import { FinanceChart } from '@/components/finance/finance-chart';

export default function FinancePage() {
  // 1. Consume the modular Zustand finance store
  const {
    transactions,
    loading,
    loadTransactions,
    addTransaction,
    editTransaction,
    removeTransaction,
  } = useFinanceStore();

  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingTransactionId, setEditingTransactionId] = useState(null);
  const [filterType, setFilterType] = useState('all');

  // 2. Fetch transactions from the API on mount
  useEffect(() => {
    loadTransactions();
  }, [loadTransactions]);

  // 3. Safe calculations for totals
  const stats = useMemo(() => {
    const txList = transactions || [];
    const income = txList
      .filter((t) => t.type === 'income')
      .reduce((sum, t) => sum + (Number(t.amount) || 0), 0);
    const expenses = txList
      .filter((t) => t.type === 'expense')
      .reduce((sum, t) => sum + (Number(t.amount) || 0), 0);
    return {
      income,
      expenses,
      net: income - expenses,
    };
  }, [transactions]);

  // 4. Safe categorization breakdown
  const transactionsByCategory = useMemo(() => {
    const grouped = {};
    const txList = transactions || [];
    txList.forEach((t) => {
      const category = t.category || 'Uncategorized';
      const amount = Number(t.amount) || 0;
      grouped[category] = (grouped[category] || 0) + (t.type === 'income' ? amount : -amount);
    });
    return Object.entries(grouped).map(([category, total]) => ({
      category,
      total,
    }));
  }, [transactions]);

  // 5. Filter transactions list
  const filteredTransactions = useMemo(() => {
    const txList = transactions || [];
    return txList.filter((t) => {
      if (filterType === 'all') return true;
      return t.type === filterType;
    });
  }, [transactions, filterType]);

  // Async handlers connecting to backend API via Zustand
  const handleCreateTransaction = async (transactionData) => {
    try {
      await addTransaction(transactionData);
      setIsDialogOpen(false);
    } catch (error) {
      console.error('Failed to create transaction:', error);
    }
  };

  const handleUpdateTransaction = async (transactionData) => {
    if (editingTransactionId) {
      try {
        await editTransaction(editingTransactionId, transactionData);
        setEditingTransactionId(null);
        setIsDialogOpen(false);
      } catch (error) {
        console.error('Failed to update transaction:', error);
      }
    }
  };

  const handleDeleteTransaction = async (id) => {
    try {
      await removeTransaction(id);
    } catch (error) {
      console.error('Failed to delete transaction:', error);
    }
  };

  return (
    <div className="min-h-screen bg-background p-8">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-4xl font-bold text-foreground mb-2">Finance</h1>
            <p className="text-muted-foreground">Track your income and expenses</p>
          </div>
          <Button
            onClick={() => {
              setEditingTransactionId(null);
              setIsDialogOpen(true);
            }}
            className="gap-2"
          >
            <Plus className="w-4 h-4" />
            New Transaction
          </Button>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
          <Card>
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <CardTitle className="text-sm font-medium text-muted-foreground">
                  Total Income
                </CardTitle>
                <TrendingUp className="w-5 h-5 text-primary" />
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-3xl font-bold text-primary">K{stats.income.toFixed(2)}</p>
              <p className="text-xs text-muted-foreground mt-2">
                {(transactions || []).filter((t) => t.type === 'income').length} transactions
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <CardTitle className="text-sm font-medium text-muted-foreground">
                  Total Expenses
                </CardTitle>
                <TrendingDown className="w-5 h-5 text-destructive" />
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-3xl font-bold text-destructive">K{stats.expenses.toFixed(2)}</p>
              <p className="text-xs text-muted-foreground mt-2">
                {(transactions || []).filter((t) => t.type === 'expense').length} transactions
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                Net Balance
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p
                className={`text-3xl font-bold ${
                  stats.net >= 0 ? 'text-primary' : 'text-destructive'
                }`}
              >
                K{stats.net.toFixed(2)}
              </p>
              <p className="text-xs text-muted-foreground mt-2">
                {stats.net >= 0 ? 'Surplus' : 'Deficit'}
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Charts and Details Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
          {/* Chart */}
          <Card className="lg:col-span-2">
            <CardHeader>
              <CardTitle>Transaction History</CardTitle>
            </CardHeader>
            <CardContent>
              <FinanceChart transactions={transactions || []} />
            </CardContent>
          </Card>

          {/* Categories Breakdown */}
          <Card>
            <CardHeader>
              <CardTitle>By Category</CardTitle>
            </CardHeader>
            <CardContent>
              {transactionsByCategory.length > 0 ? (
                <div className="space-y-3">
                  {transactionsByCategory.map((item) => (
                    <div key={item.category} className="flex items-center justify-between">
                      <span className="text-sm text-foreground">{item.category}</span>
                      <span
                        className={`text-sm font-medium ${
                          item.total >= 0 ? 'text-primary' : 'text-destructive'
                        }`}
                      >
                        K{Math.abs(item.total).toFixed(2)}
                      </span>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-sm text-muted-foreground">No transactions yet</p>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Transactions List */}
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle>Recent Transactions</CardTitle>
              <div className="flex gap-2">
                {['all', 'income', 'expense'].map((type) => (
                  <button
                    key={type}
                    onClick={() => setFilterType(type)}
                    className={`px-3 py-1 text-xs rounded transition-colors ${
                      filterType === type
                        ? 'bg-primary text-primary-foreground'
                        : 'bg-card border border-border text-foreground hover:border-primary/50'
                    }`}
                  >
                    {type.charAt(0).toUpperCase() + type.slice(1)}
                  </button>
                ))}
              </div>
            </div>
          </CardHeader>
          <CardContent>
            {loading ? (
              <div className="flex items-center justify-center py-8 text-muted-foreground gap-2">
                <Loader2 className="w-5 h-5 animate-spin" />
                <p className="text-sm">Loading transactions...</p>
              </div>
            ) : filteredTransactions.length > 0 ? (
              <div className="space-y-3 max-h-96 overflow-y-auto">
                {filteredTransactions.map((transaction) => {
                  const amount = Number(transaction.amount) || 0;
                  const txDate = transaction.date || transaction.created_at;

                  return (
                    <div
                      key={transaction.id}
                      className="flex items-center justify-between p-3 bg-card/50 rounded-lg border border-border hover:border-primary/50 transition-colors"
                    >
                      <div className="flex-1">
                        <div className="font-medium text-foreground">{transaction.description}</div>
                        <div className="text-xs text-muted-foreground">
                          {transaction.category} •{' '}
                          {txDate ? new Date(txDate).toLocaleDateString() : 'N/A'}
                        </div>
                      </div>
                      <div className="flex items-center gap-3">
                        <span
                          className={`font-bold ${
                            transaction.type === 'income'
                              ? 'text-primary'
                              : 'text-destructive'
                          }`}
                        >
                          {transaction.type === 'income' ? '+' : '-'}K
                          {amount.toFixed(2)}
                        </span>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => {
                            setEditingTransactionId(transaction.id);
                            setIsDialogOpen(true);
                          }}
                        >
                          <Edit className="w-4 h-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleDeleteTransaction(transaction.id)}
                          className="text-destructive hover:text-destructive"
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  );
                })}
              </div>
            ) : (
              <p className="text-muted-foreground text-sm text-center py-8">
                No transactions found
              </p>
            )}
          </CardContent>
        </Card>

        {/* Finance Dialog */}
        <FinanceDialog
          isOpen={isDialogOpen}
          onClose={() => {
            setIsDialogOpen(false);
            setEditingTransactionId(null);
          }}
          onSave={
            editingTransactionId ? handleUpdateTransaction : handleCreateTransaction
          }
          initialTransaction={
            editingTransactionId
              ? (transactions || []).find((t) => t.id === editingTransactionId)
              : undefined
          }
        />
      </div>
    </div>
  );
}