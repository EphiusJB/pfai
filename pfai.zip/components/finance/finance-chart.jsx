'use client';

import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { FinanceTransaction } from '@/app/providers';
import { useState } from 'react';

export function FinanceChart({ transactions }) {
  const [chartType, setChartType] = useState('line');

  // Group transactions by date
  const chartData = [...transactions]
  .sort((a, b) => new Date(a.created_at).getTime() - new Date(b.created_at).getTime())
  .reduce((acc, currentTransaction) => {
    // 1. Get the date string from the current item being looked at
    const dateStr = new Date(currentTransaction.created_at).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
    });

    // 2. Look for an existing group matching this date
    let existing = acc.find((item) => item.created_at === dateStr);
    if (!existing) {
      existing = { date: dateStr, income: 0, expense: 0, net: 0 };
      acc.push(existing);
    }

    // 3. Add values to the group using the current transaction properties
    if (currentTransaction.type === 'income') {
      existing.income += currentTransaction.amount;
    } else if (currentTransaction.type === 'expense') {
      existing.expense += currentTransaction.amount;
    }
    
    // 4. Calculate net total (income minus expenses)
    existing.net = existing.income - existing.expense;

    return acc;
  }, []);


  if (transactions.length === 0) {
    return (
      <div className="flex items-center justify-center h-64 text-muted-foreground">
        No transaction data to display
      </div>
    );
  }

  return (
    <div className="w-full space-y-4">
      <div className="flex gap-2">
        <button
          onClick={() => setChartType('line')}
          className={`px-3 py-1 text-xs rounded transition-colors ${
            chartType === 'line'
              ? 'bg-primary text-primary-foreground'
              : 'bg-card border border-border text-foreground hover:border-primary/50'
          }`}
        >
          Line Chart
        </button>
        <button
          onClick={() => setChartType('bar')}
          className={`px-3 py-1 text-xs rounded transition-colors ${
            chartType === 'bar'
              ? 'bg-primary text-primary-foreground'
              : 'bg-card border border-border text-foreground hover:border-primary/50'
          }`}
        >
          Bar Chart
        </button>
      </div>

      {chartType === 'line' ? (
        <ResponsiveContainer width="100%" height={300}>
          <LineChart data={chartData}>
            <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.1)" />
            <XAxis dataKey="date" stroke="rgba(255,255,255,0.5)" />
            <YAxis stroke="rgba(255,255,255,0.5)" />
            <Tooltip
              contentStyle={{
                backgroundColor: 'rgba(0, 0, 0, 0.8)',
                border: '1px solid rgba(255,255,255,0.2)',
                borderRadius: '8px',
              }}
            />
            <Legend />
            <Line
              type="monotone"
              dataKey="income"
              stroke="#00ff00"
              name="Income"
              dot={false}
            />
            <Line
              type="monotone"
              dataKey="expense"
              stroke="#ff6b6b"
              name="Expense"
              dot={false}
            />
            <Line
              type="monotone"
              dataKey="net"
              stroke="#4a9eff"
              name="Net"
              dot={false}
            />
          </LineChart>
        </ResponsiveContainer>
      ) : (
        <ResponsiveContainer width="100%" height={300}>
          <BarChart data={chartData}>
            <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.1)" />
            <XAxis dataKey="date" stroke="rgba(255,255,255,0.5)" />
            <YAxis stroke="rgba(255,255,255,0.5)" />
            <Tooltip
              contentStyle={{
                backgroundColor: 'rgba(0, 0, 0, 0.8)',
                border: '1px solid rgba(255,255,255,0.2)',
                borderRadius: '8px',
              }}
            />
            <Legend />
            <Bar dataKey="income" fill="#00ff00" name="Income" />
            <Bar dataKey="expense" fill="#ff6b6b" name="Expense" />
          </BarChart>
        </ResponsiveContainer>
      )}
    </div>
  );
}
