'use client';

import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Checkbox } from '@/components/ui/checkbox';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Plus, Trash2, Edit2, Check, Clock, ListChecks } from 'lucide-react';

export function ManageMilestonesDialog({
  isOpen,
  onClose,
  goal,
  milestones = [],
  onAddMilestone,
  onUpdateMilestone,
  onDeleteMilestone,
  onAddTask,
  onToggleTask,
  onDeleteTask,
}) {
  const [newMilestoneTitle, setNewMilestoneTitle] = useState('');
  const [editingMilestoneId, setEditingMilestoneId] = useState(null);
  const [editingMilestoneTitle, setEditingMilestoneTitle] = useState('');
  
  // Track separate task title and XP inputs per milestone
  const [taskInputs, setTaskInputs] = useState({});
  const [taskXpInputs, setTaskXpInputs] = useState({});

  if (!goal) return null;

  const handleAddMilestone = () => {
    if (!newMilestoneTitle.trim()) return;
    onAddMilestone(goal.id, newMilestoneTitle);
    setNewMilestoneTitle('');
  };

  const handleStartEditMilestone = (milestone) => {
    setEditingMilestoneId(milestone.id);
    setEditingMilestoneTitle(milestone.title);
  };

  const handleSaveMilestoneTitle = (milestoneId) => {
    if (editingMilestoneTitle.trim() && onUpdateMilestone) {
      onUpdateMilestone(milestoneId, { title: editingMilestoneTitle });
    }
    setEditingMilestoneId(null);
  };

  const handleStatusChange = (milestoneId, newStatus) => {
    if (onUpdateMilestone) {
      onUpdateMilestone(milestoneId, { status: newStatus });
    }
  };

  const handleAddTask = (milestoneId) => {
    const title = taskInputs[milestoneId];
    const xp = parseInt(taskXpInputs[milestoneId] || '10', 10);

    if (!title || !title.trim()) return;

    onAddTask(milestoneId, title, xp);
    
    setTaskInputs({ ...taskInputs, [milestoneId]: '' });
    setTaskXpInputs({ ...taskXpInputs, [milestoneId]: '10' });
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-h-[85vh] overflow-y-auto max-w-2xl">
        <DialogHeader>
          <div className="flex items-center gap-2">
            <DialogTitle>Manage Milestones — {goal.title}</DialogTitle>
            <span className="text-xs px-2 py-0.5 rounded bg-muted font-medium flex items-center gap-1">
              {goal.type === 'timed' ? <Clock className="w-3 h-3" /> : <ListChecks className="w-3 h-3" />}
              {goal.type}
            </span>
          </div>
        </DialogHeader>

        <div className="space-y-6 py-2">
          {/* Add Milestone Input */}
          <div className="flex gap-2">
            <Input
              placeholder="New milestone title..."
              value={newMilestoneTitle}
              onChange={(e) => setNewMilestoneTitle(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleAddMilestone()}
            />
            <Button onClick={handleAddMilestone} variant="secondary" className="gap-1 shrink-0">
              <Plus className="w-4 h-4" /> Add Milestone
            </Button>
          </div>

          {/* Milestones List */}
          <div className="space-y-4">
            {milestones.length === 0 ? (
              <p className="text-xs text-center text-muted-foreground py-4 border border-dashed rounded-lg">
                No milestones added yet. Add one above to break down your goal.
              </p>
            ) : (
              milestones.map((milestone) => (
                <div key={milestone.id} className="border rounded-lg p-4 bg-card">
                  {/* Milestone Header */}
                  <div className="flex justify-between items-center mb-3 gap-2">
                    {editingMilestoneId === milestone.id ? (
                      <div className="flex items-center gap-2 flex-1">
                        <Input
                          size="sm"
                          value={editingMilestoneTitle}
                          onChange={(e) => setEditingMilestoneTitle(e.target.value)}
                          className="h-8 text-sm"
                        />
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => handleSaveMilestoneTitle(milestone.id)}
                          className="h-8 w-8 p-0"
                        >
                          <Check className="w-4 h-4 text-green-600" />
                        </Button>
                      </div>
                    ) : (
                      <div className="flex items-center gap-2">
                        <h4 className="font-semibold text-sm">{milestone.title}</h4>
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => handleStartEditMilestone(milestone)}
                          className="h-6 w-6 p-0 text-muted-foreground"
                        >
                          <Edit2 className="w-3 h-3" />
                        </Button>
                      </div>
                    )}

                    <div className="flex items-center gap-2">
                      <Select
                        value={milestone.status || 'not-started'}
                        onValueChange={(status) => handleStatusChange(milestone.id, status)}
                      >
                        <SelectTrigger className="h-7 text-xs w-[115px]">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="not-started">Not Started</SelectItem>
                          <SelectItem value="in-progress">In Progress</SelectItem>
                          <SelectItem value="completed">Completed</SelectItem>
                        </SelectContent>
                      </Select>

                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => onDeleteMilestone(milestone.id)}
                        className="text-destructive h-7 w-7 p-0"
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>

                  {/* Tasks in Milestone */}
                  <div className="ml-2 pl-3 border-l space-y-2">
                    {(milestone.tasks || []).map((task) => (
                      <div key={task.id} className="flex items-center justify-between text-xs py-1">
                        <div className="flex items-center gap-2">
                          <Checkbox
                            checked={task.is_completed}
                            onCheckedChange={(checked) => onToggleTask(task.id, checked)}
                          />
                          <span className={task.is_completed ? 'line-through text-muted-foreground' : ''}>
                            {task.title}
                          </span>
                        </div>

                        <div className="flex items-center gap-3">
                          {task.xp > 0 && (
                            <span className="text-[10px] bg-primary/10 text-primary px-1.5 py-0.5 rounded font-mono">
                              +{task.xp} XP
                            </span>
                          )}
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => onDeleteTask(task.id)}
                            className="text-destructive h-5 w-5 p-0"
                          >
                            <Trash2 className="w-3 h-3" />
                          </Button>
                        </div>
                      </div>
                    ))}

                    {/* Inline Task Creation */}
                    <div className="flex gap-2 pt-2">
                      <Input
                        placeholder="Add task title..."
                        className="text-xs h-8 flex-1"
                        value={taskInputs[milestone.id] || ''}
                        onChange={(e) => setTaskInputs({ ...taskInputs, [milestone.id]: e.target.value })}
                        onKeyDown={(e) => e.key === 'Enter' && handleAddTask(milestone.id)}
                      />
                      <Input
                        type="number"
                        placeholder="XP"
                        className="text-xs h-8 w-16"
                        value={taskXpInputs[milestone.id] ?? '10'}
                        onChange={(e) => setTaskXpInputs({ ...taskXpInputs, [milestone.id]: e.target.value })}
                      />
                      <Button
                        size="sm"
                        variant="outline"
                        className="h-8 text-xs gap-1 shrink-0"
                        onClick={() => handleAddTask(milestone.id)}
                      >
                        <Plus className="w-3 h-3" /> Task
                      </Button>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

        <DialogFooter>
          <Button onClick={onClose}>Done</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}