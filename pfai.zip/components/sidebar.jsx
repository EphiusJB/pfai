"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { Zap, Target, BookOpen, CreditCard, BarChart3 } from "lucide-react";
import { cn } from "@/lib/utils";
import { useAuthStore } from "@/lib/store/AuthStore";

const navItems = [
  {
    href: "/dashboard",
    label: "Dashboard",
    icon: BarChart3,
  },
  {
    href: "/goals",
    label: "Goals",
    icon: Target,
  },
  {
    href: "/journal",
    label: "Journal",
    icon: BookOpen,
  },
  {
    href: "/finance",
    label: "Finance",
    icon: CreditCard,
  },
];

export function Sidebar() {
  const pathname = usePathname();
  const user = useAuthStore((s) => s.user);
  const profile = useAuthStore((s) => s.profile);
  console.log(profile)

  return (
    <aside className="w-16 bg-sidebar border-r border-sidebar-border flex flex-col items-center py-6 gap-8 fixed left-0 top-0 h-screen">
      {/* Logo */}
      <Link
        href="/dashboard"
        className="flex items-center justify-center w-12 h-12 rounded-lg bg-primary text-primary-foreground hover:opacity-90 transition-opacity"
      >
        <Zap className="w-6 h-6" />
      </Link>

      {/* Navigation */}
      <nav className="flex flex-col gap-4 flex-1">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = pathname.startsWith(item.href);
          return (
            <Link
              key={item.href}
              href={item.href}
              className={cn(
                "flex items-center justify-center w-12 h-12 rounded-lg transition-all relative group",
                isActive
                  ? "bg-primary text-primary-foreground"
                  : "text-sidebar-foreground hover:bg-sidebar-accent/10"
              )}
              title={item.label}
            >
              <Icon className="w-5 h-5" />
              {/* Tooltip */}
              <div className="absolute left-16 bg-card text-card-foreground px-2 py-1 rounded text-sm whitespace-nowrap pointer-events-none opacity-0 group-hover:opacity-100 transition-opacity">
                {item.label}
              </div>
            </Link>
          );
        })}
      </nav>

      {/* Profile indicator */}
      <div className="w-12 h-12 rounded-lg flex items-center justify-center text-sidebar-accent cursor-pointer hover:bg-sidebar-accent/30 transition-colors">
        {profile ? (
          <img src={profile.avatar_url} className="w-8 h-8 rounded flex items-center justify-center "/>
        ) : (
          <div className="w-8 h-8 rounded flex items-center justify-center">
            1
          </div>
        )}
      </div>
    </aside>
  );
}
